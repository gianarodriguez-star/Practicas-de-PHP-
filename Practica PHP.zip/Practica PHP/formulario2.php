<html>
<head>
    <title>Ejemplo de PHP</title>
</head>
<body>
<H1> Ejemplo de procesado de formularios</H1>
El nombre que ha introducido es: <?php echo $nombre ?>
<br>
</FORM>
</body>
</html>